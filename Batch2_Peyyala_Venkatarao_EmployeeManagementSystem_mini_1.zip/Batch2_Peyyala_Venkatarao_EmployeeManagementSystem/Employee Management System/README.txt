﻿=======================================================
   EMPLOYEE MANAGEMENT SYSTEM - MINI PROJECT 1
   Student: P. Venkatarao
   Date: March 2026
=======================================================

1. HOW TO RUN THE APP
-----------------------
Step 1: Double-click index.html
Step 2: Login with:
        Username : venkatarao
        Password : venkat@123

2. HOW TO RUN THE TESTS
------------------------
Step 1: npm install
Step 2: npm test

Expected Result:
        Tests: 25 passed, 25 total

3. PROJECT STRUCTURE
---------------------
index.html           - Main HTML page
css/style.css        - Custom styles
js/data.js           - Employee data
js/storageService.js - Data store
js/authService.js    - Login/Logout
js/validationService.js - Form validation
js/employeeService.js   - CRUD operations
js/dashboardService.js  - Dashboard data
js/uiService.js      - DOM rendering
js/app.js            - Event listeners
tests/               - Unit test files
package.json         - Jest config

4. FEATURES
------------
- Login and Signup
- Dashboard with KPI cards
- Employee List with search/filter/sort
- Add, Edit, View, Delete employees
- 25 Unit Tests passing
- Responsive Bootstrap UI
=======================================================
