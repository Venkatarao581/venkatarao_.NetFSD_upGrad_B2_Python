let storedCredentials = { username: "admin", password: "admin123" };

const storageService = {
  getAdminCredentials: () => storedCredentials,
  setAdminCredentials: (u, p) => { storedCredentials = { username: u, password: p }; }
};

const authService = (() => {
  let isAuthenticated = false;
  let currentUser = null;
  function signup(username, password) {
    const existing = storageService.getAdminCredentials();
    if (existing.username === username) return { success: false, message: "Username already exists. Please choose a different username." };
    storageService.setAdminCredentials(username, password);
    return { success: true, message: "Account created successfully! Please log in." };
  }
  function login(username, password) {
    const creds = storageService.getAdminCredentials();
    if (creds.username === username && creds.password === password) {
      isAuthenticated = true;
      currentUser = username;
      return { success: true };
    }
    return { success: false, message: "Invalid credentials. Please try again." };
  }
  function logout() { isAuthenticated = false; currentUser = null; }
  function isLoggedIn() { return isAuthenticated; }
  function getCurrentUser() { return currentUser; }
  return { signup, login, logout, isLoggedIn, getCurrentUser };
})();

beforeEach(() => {
  storedCredentials = { username: "admin", password: "admin123" };
  authService.logout();
});

describe("authService — signup", () => {
  test("creates a new admin with unique username", () => {
    const result = authService.signup("newadmin", "newpass1");
    expect(result.success).toBe(true);
  });
  test("rejects duplicate username", () => {
    const result = authService.signup("admin", "anypassword");
    expect(result.success).toBe(false);
    expect(result.message).toMatch(/already exists/i);
  });
  test("stores new credentials on successful signup", () => {
    authService.signup("venkat", "venkat123");
    expect(storageService.getAdminCredentials().username).toBe("venkat");
  });
});

describe("authService — login", () => {
  test("login succeeds with correct credentials", () => {
    const result = authService.login("admin", "admin123");
    expect(result.success).toBe(true);
  });
  test("login fails with wrong password", () => {
    const result = authService.login("admin", "wrongpass");
    expect(result.success).toBe(false);
    expect(result.message).toBeTruthy();
  });
  test("login fails with wrong username", () => {
    const result = authService.login("wronguser", "admin123");
    expect(result.success).toBe(false);
  });
  test("does not reveal which field is wrong", () => {
    const r1 = authService.login("admin", "wrongpass");
    const r2 = authService.login("wronguser", "admin123");
    expect(r1.message).toBe(r2.message);
  });
});

describe("authService — session state", () => {
  test("isLoggedIn returns false before login", () => {
    expect(authService.isLoggedIn()).toBe(false);
  });
  test("isLoggedIn returns true after successful login", () => {
    authService.login("admin", "admin123");
    expect(authService.isLoggedIn()).toBe(true);
  });
  test("getCurrentUser returns username after login", () => {
    authService.login("admin", "admin123");
    expect(authService.getCurrentUser()).toBe("admin");
  });
  test("logout clears session flag", () => {
    authService.login("admin", "admin123");
    authService.logout();
    expect(authService.isLoggedIn()).toBe(false);
  });
  test("getCurrentUser returns null after logout", () => {
    authService.login("admin", "admin123");
    authService.logout();
    expect(authService.getCurrentUser()).toBeNull();
  });
});