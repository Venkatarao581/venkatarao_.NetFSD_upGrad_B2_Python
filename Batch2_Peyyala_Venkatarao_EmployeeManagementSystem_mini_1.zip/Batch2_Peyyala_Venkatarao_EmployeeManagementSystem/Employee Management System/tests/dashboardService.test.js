const mockEmployees = [
  { id: 1, firstName: "Priya",  lastName: "Prabhu",  department: "Engineering", status: "Active"   },
  { id: 2, firstName: "Arjun",  lastName: "Sharma",  department: "Marketing",   status: "Active"   },
  { id: 3, firstName: "Vikram", lastName: "Raj",     department: "Engineering", status: "Inactive" },
  { id: 4, firstName: "Neha",   lastName: "Kapoor",  department: "HR",          status: "Active"   },
  { id: 5, firstName: "Rahul",  lastName: "Verma",   department: "Finance",     status: "Inactive" },
  { id: 6, firstName: "Sneha",  lastName: "Prasad",  department: "Operations",  status: "Active"   },
];

const employeeService = {
  getAll: () => [...mockEmployees]
};

const dashboardService = (() => {
  function getSummary() {
    const all = employeeService.getAll();
    return {
      total:       all.length,
      active:      all.filter(e => e.status === "Active").length,
      inactive:    all.filter(e => e.status === "Inactive").length,
      departments: [...new Set(all.map(e => e.department))].length
    };
  }
  function getDepartmentBreakdown() {
    const all = employeeService.getAll();
    const total = all.length;
    const map = {};
    all.forEach(e => { map[e.department] = (map[e.department] || 0) + 1; });
    return Object.entries(map)
      .map(([department, count]) => ({ department, count, percentage: Math.round((count / total) * 100) }))
      .sort((a, b) => b.count - a.count);
  }
  function getRecentEmployees(n) {
    return [...employeeService.getAll()].sort((a, b) => b.id - a.id).slice(0, n);
  }
  return { getSummary, getDepartmentBreakdown, getRecentEmployees };
})();

describe("dashboardService — getSummary", () => {
  test("returns correct total employee count", () => {
    expect(dashboardService.getSummary().total).toBe(6);
  });
  test("returns correct active count", () => {
    expect(dashboardService.getSummary().active).toBe(4);
  });
  test("returns correct inactive count", () => {
    expect(dashboardService.getSummary().inactive).toBe(2);
  });
  test("returns correct number of unique departments", () => {
    expect(dashboardService.getSummary().departments).toBe(5);
  });
  test("active + inactive equals total", () => {
    const s = dashboardService.getSummary();
    expect(s.active + s.inactive).toBe(s.total);
  });
});

describe("dashboardService — getDepartmentBreakdown", () => {
  test("returns an entry for each unique department", () => {
    expect(dashboardService.getDepartmentBreakdown()).toHaveLength(5);
  });
  test("Engineering has count of 2", () => {
    const eng = dashboardService.getDepartmentBreakdown().find(d => d.department === "Engineering");
    expect(eng.count).toBe(2);
  });
  test("percentages are numbers between 0 and 100", () => {
    dashboardService.getDepartmentBreakdown().forEach(d => {
      expect(d.percentage).toBeGreaterThanOrEqual(0);
      expect(d.percentage).toBeLessThanOrEqual(100);
    });
  });
  test("sorted by count descending", () => {
    const breakdown = dashboardService.getDepartmentBreakdown();
    for (let i = 0; i < breakdown.length - 1; i++) {
      expect(breakdown[i].count).toBeGreaterThanOrEqual(breakdown[i + 1].count);
    }
  });
});

describe("dashboardService — getRecentEmployees", () => {
  test("returns correct number of recent employees", () => {
    expect(dashboardService.getRecentEmployees(3)).toHaveLength(3);
  });
  test("returns employees with highest IDs first", () => {
    const recent = dashboardService.getRecentEmployees(3);
    expect(recent[0].id).toBe(6);
    expect(recent[1].id).toBe(5);
    expect(recent[2].id).toBe(4);
  });
  test("returns all if n is greater than total employees", () => {
    expect(dashboardService.getRecentEmployees(100)).toHaveLength(6);
  });
  test("returns 5 recent employees correctly", () => {
    const recent = dashboardService.getRecentEmployees(5);
    expect(recent).toHaveLength(5);
    expect(recent[0].id).toBeGreaterThan(recent[1].id);
  });
});