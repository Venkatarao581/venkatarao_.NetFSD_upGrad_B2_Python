let employees;

const storageService = {
  getAll: () => [...employees],
  getById: (id) => employees.find(e => e.id === id),
  add: (emp) => employees.push(emp),
  update: (id, data) => {
    const idx = employees.findIndex(e => e.id === id);
    if (idx !== -1) employees[idx] = { ...employees[idx], ...data };
  },
  remove: (id) => {
    const idx = employees.findIndex(e => e.id === id);
    if (idx !== -1) employees.splice(idx, 1);
  },
  nextId: () => employees.length === 0 ? 1 : Math.max(...employees.map(e => e.id)) + 1,
};

const employeeService = (() => {
  function getAll() { return storageService.getAll(); }
  function getById(id) { return storageService.getById(id); }
  function add(data) {
    const emp = { id: storageService.nextId(), ...data, salary: Number(data.salary) };
    storageService.add(emp);
    return emp;
  }
  function update(id, data) { storageService.update(id, { ...data, salary: Number(data.salary) }); }
  function remove(id) { storageService.remove(id); }
  function search(q) {
    if (!q) return getAll();
    const query = q.toLowerCase();
    return getAll().filter(e => `${e.firstName} ${e.lastName}`.toLowerCase().includes(query) || e.email.toLowerCase().includes(query));
  }
  function filterByDepartment(dept) {
    if (!dept || dept === "All") return getAll();
    return getAll().filter(e => e.department === dept);
  }
  function filterByStatus(status) {
    if (!status || status === "All") return getAll();
    return getAll().filter(e => e.status === status);
  }
  function applyFilters(sq, dept, status) {
    let r = getAll();
    if (sq) r = r.filter(e => `${e.firstName} ${e.lastName}`.toLowerCase().includes(sq.toLowerCase()) || e.email.toLowerCase().includes(sq.toLowerCase()));
    if (dept && dept !== "All") r = r.filter(e => e.department === dept);
    if (status && status !== "All") r = r.filter(e => e.status === status);
    return r;
  }
  function sortBy(list, field, dir) {
    const s = [...list];
    s.sort((a, b) => {
      if (field === "name") return dir === "asc" ? a.lastName.localeCompare(b.lastName) : b.lastName.localeCompare(a.lastName);
      if (field === "salary") return dir === "asc" ? a.salary - b.salary : b.salary - a.salary;
      if (field === "joinDate") return dir === "asc" ? new Date(a.joinDate) - new Date(b.joinDate) : new Date(b.joinDate) - new Date(a.joinDate);
      return 0;
    });
    return s;
  }
  return { getAll, getById, add, update, remove, search, filterByDepartment, filterByStatus, applyFilters, sortBy };
})();

beforeEach(() => {
  employees = [
    { id: 1, firstName: "Priya",  lastName: "Prabhu",  email: "priya@test.com",  phone: "9876543210", department: "Engineering", designation: "Engineer",  salary: 850000, joinDate: "2021-03-15", status: "Active"   },
    { id: 2, firstName: "Arjun",  lastName: "Sharma",  email: "arjun@test.com",  phone: "9876543211", department: "Marketing",   designation: "Executive", salary: 630000, joinDate: "2020-07-01", status: "Active"   },
    { id: 3, firstName: "Vikram", lastName: "Raj",     email: "vikram@test.com", phone: "9876543212", department: "Engineering", designation: "Senior Dev",salary: 1100000,joinDate: "2017-09-12", status: "Inactive" },
    { id: 4, firstName: "Neha",   lastName: "Kapoor",  email: "neha@test.com",   phone: "9876543213", department: "HR",          designation: "HR Exec",   salary: 550000, joinDate: "2019-11-23", status: "Active"   },
    { id: 5, firstName: "Rahul",  lastName: "Verma",   email: "rahul@test.com",  phone: "9876543214", department: "Finance",     designation: "Analyst",   salary: 730000, joinDate: "2022-01-10", status: "Inactive" },
  ];
});

describe("employeeService — getAll", () => {
  test("returns all employees", () => {
    expect(employeeService.getAll()).toHaveLength(5);
  });
  test("returns a copy, not the original array", () => {
    const result = employeeService.getAll();
    result.push({ id: 99 });
    expect(employeeService.getAll()).toHaveLength(5);
  });
});

describe("employeeService — add", () => {
  test("adds a new employee with auto-incremented ID", () => {
    const emp = employeeService.add({ firstName: "Test", lastName: "User", email: "test@test.com", phone: "9876500000", department: "HR", designation: "Tester", salary: "500000", joinDate: "2023-01-01", status: "Active" });
    expect(employeeService.getAll()).toHaveLength(6);
    expect(emp.id).toBe(6);
  });
  test("salary is stored as a number", () => {
    const emp = employeeService.add({ firstName: "A", lastName: "B", email: "ab@test.com", phone: "9876500001", department: "HR", designation: "X", salary: "750000", joinDate: "2023-01-01", status: "Active" });
    expect(typeof emp.salary).toBe("number");
    expect(emp.salary).toBe(750000);
  });
});

describe("employeeService — update", () => {
  test("updates an existing employee's salary", () => {
    employeeService.update(1, { salary: "999999" });
    expect(employeeService.getById(1).salary).toBe(999999);
  });
  test("does not change unrelated fields", () => {
    employeeService.update(1, { salary: "999999" });
    expect(employeeService.getById(1).firstName).toBe("Priya");
  });
});

describe("employeeService — remove", () => {
  test("removes an employee by ID", () => {
    employeeService.remove(1);
    expect(employeeService.getAll()).toHaveLength(4);
    expect(employeeService.getById(1)).toBeUndefined();
  });
  test("IDs do not duplicate after deletion", () => {
    employeeService.remove(3);
    const newEmp = employeeService.add({ firstName: "New", lastName: "Person", email: "new@test.com", phone: "9876500002", department: "HR", designation: "X", salary: "500000", joinDate: "2023-01-01", status: "Active" });
    expect(newEmp.id).toBe(6);
  });
});

describe("employeeService — search", () => {
  test("finds employees by first name", () => {
    expect(employeeService.search("Priya")).toHaveLength(1);
  });
  test("finds employees by last name", () => {
    expect(employeeService.search("Raj")).toHaveLength(1);
  });
  test("finds employees by email", () => {
    expect(employeeService.search("arjun@test.com")).toHaveLength(1);
  });
  test("is case-insensitive", () => {
    expect(employeeService.search("PRIYA")).toHaveLength(1);
  });
  test("returns empty array when no match", () => {
    expect(employeeService.search("xyz_no_match")).toHaveLength(0);
  });
  test("returns all when query is empty", () => {
    expect(employeeService.search("")).toHaveLength(5);
  });
});

describe("employeeService — filterByDepartment", () => {
  test("filters by Engineering", () => {
    expect(employeeService.filterByDepartment("Engineering")).toHaveLength(2);
  });
  test("returns all when dept is All", () => {
    expect(employeeService.filterByDepartment("All")).toHaveLength(5);
  });
});

describe("employeeService — filterByStatus", () => {
  test("returns only Active employees", () => {
    const active = employeeService.filterByStatus("Active");
    expect(active.every(e => e.status === "Active")).toBe(true);
  });
  test("returns only Inactive employees", () => {
    const inactive = employeeService.filterByStatus("Inactive");
    expect(inactive.every(e => e.status === "Inactive")).toBe(true);
  });
});

describe("employeeService — applyFilters (AND logic)", () => {
  test("search + dept + status combined", () => {
    const result = employeeService.applyFilters("Priya", "Engineering", "Active");
    expect(result).toHaveLength(1);
    expect(result[0].firstName).toBe("Priya");
  });
  test("returns empty when no employee matches all filters", () => {
    expect(employeeService.applyFilters("Priya", "Finance", "Active")).toHaveLength(0);
  });
});

describe("employeeService — sortBy", () => {
  test("sorts by name ascending (lastName A-Z)", () => {
    const sorted = employeeService.sortBy(employeeService.getAll(), "name", "asc");
    expect(sorted[0].lastName).toBe("Kapoor");
  });
  test("sorts by salary descending", () => {
    const sorted = employeeService.sortBy(employeeService.getAll(), "salary", "desc");
    expect(sorted[0].salary).toBe(1100000);
  });
  test("sorts by joinDate ascending (oldest first)", () => {
    const sorted = employeeService.sortBy(employeeService.getAll(), "joinDate", "asc");
    expect(sorted[0].joinDate).toBe("2017-09-12");
  });
});