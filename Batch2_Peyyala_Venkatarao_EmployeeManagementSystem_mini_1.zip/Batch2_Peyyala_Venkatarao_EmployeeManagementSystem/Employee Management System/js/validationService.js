const validationService = (() => {
  
  function validateAuthForm(formData) {
    const errors = {};
    const { username, password, confirmPassword } = formData;

    if (!username || username.trim() === "") {
      errors.username = "Username is required.";
    }
    if (!password || password.trim() === "") {
      errors.password = "Password is required.";
    } else if (password.length < 6) {
      errors.password = "Password must be at least 6 characters.";
    }
    if (confirmPassword !== undefined) {
      if (!confirmPassword || confirmPassword.trim() === "") {
        errors.confirmPassword = "Please confirm your password.";
      } else if (password !== confirmPassword) {
        errors.confirmPassword = "Passwords do not match.";
      }
    }
    return errors;
  }

  function validateEmployeeForm(formData) {
    const errors = {};
    const { firstName, lastName, email, phone, department, designation, salary, joinDate, status, editingId } = formData;

    if (!firstName || firstName.trim() === "") errors.firstName = "First name is required.";
    if (!lastName  || lastName.trim()  === "") errors.lastName  = "Last name is required.";

    if (!email || email.trim() === "") {
      errors.email = "Email is required.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errors.email = "Enter a valid email address.";
    } else {
      const all = storageService.getAll();
      const duplicate = all.find(e => e.email.toLowerCase() === email.toLowerCase() && e.id !== Number(editingId));
      if (duplicate) errors.email = "This email is already registered.";
    }

    if (!phone || phone.trim() === "") {
      errors.phone = "Phone number is required.";
    } else if (!/^\d{10}$/.test(phone.trim())) {
      errors.phone = "Phone must be exactly 10 digits.";
    }

    if (!department || department === "") errors.department = "Please select a department.";
    if (!designation || designation.trim() === "") errors.designation = "Designation is required.";

    if (!salary || salary === "") {
      errors.salary = "Salary is required.";
    } else if (isNaN(salary) || Number(salary) <= 0) {
      errors.salary = "Salary must be a positive number.";
    }

    if (!joinDate || joinDate.trim() === "") errors.joinDate = "Join date is required.";
    if (!status || status === "") errors.status = "Please select a status.";

    return errors;
  }

  return { validateAuthForm, validateEmployeeForm };
})();