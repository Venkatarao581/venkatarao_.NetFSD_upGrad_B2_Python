const employees = [
  { id: 1,  firstName: "Priya",    lastName: "Prabhu",    email: "priya.prabhu@nexacore.com",    phone: "9876543210", department: "Engineering",  designation: "Software Engineer",    salary: 850000,  joinDate: "2021-03-15", status: "Active"   },
  { id: 2,  firstName: "Arjun",    lastName: "Sharma",    email: "arjun.sharma@nexacore.com",    phone: "9876543211", department: "Marketing",    designation: "Marketing Executive",  salary: 630000,  joinDate: "2020-07-01", status: "Active"   },
  { id: 3,  firstName: "Neha",     lastName: "Kapoor",    email: "neha.kapoor@nexacore.com",     phone: "9876543212", department: "HR",           designation: "HR Executive",         salary: 550000,  joinDate: "2019-11-23", status: "Active"   },
  { id: 4,  firstName: "Rahul",    lastName: "Verma",     email: "rahul.verma@nexacore.com",     phone: "9876543213", department: "Finance",      designation: "Financial Analyst",    salary: 730000,  joinDate: "2022-01-10", status: "Active"   },
  { id: 5,  firstName: "Sneha",    lastName: "Prasad",    email: "sneha.prasad@nexacore.com",    phone: "9876543214", department: "Operations",   designation: "Operations Manager",   salary: 950000,  joinDate: "2018-06-05", status: "Active"   },
  { id: 6,  firstName: "Vikram",   lastName: "Raj",       email: "vikram.raj@nexacore.com",      phone: "9876543215", department: "Engineering",  designation: "Senior Developer",     salary: 1100000, joinDate: "2017-09-12", status: "Inactive" },
  { id: 7,  firstName: "Ananya",   lastName: "Singh",     email: "ananya.singh@nexacore.com",    phone: "9876543216", department: "Marketing",    designation: "Content Strategist",   salary: 580000,  joinDate: "2023-02-28", status: "Inactive" },
  { id: 8,  firstName: "Karthik",  lastName: "Rajan",     email: "karthik.rajan@nexacore.com",   phone: "9876543217", department: "Finance",      designation: "Accounts Manager",     salary: 800000,  joinDate: "2020-04-17", status: "Active"   },
  { id: 9,  firstName: "Lakshmi",  lastName: "Chandran",  email: "lakshmi.chandran@nexacore.com",phone: "9876543218", department: "HR",           designation: "HR Manager",           salary: 720000,  joinDate: "2019-08-30", status: "Active"   },
  { id: 10, firstName: "Amit",     lastName: "Joshi",     email: "amit.joshi@nexacore.com",      phone: "9876543219", department: "Operations",   designation: "Supply Chain Analyst", salary: 660000,  joinDate: "2021-11-14", status: "Active"   },
  { id: 11, firstName: "Pooja",    lastName: "Ghosh",     email: "pooja.ghosh@nexacore.com",     phone: "9876543220", department: "Engineering",  designation: "DevOps Engineer",      salary: 920000,  joinDate: "2022-05-20", status: "Active"   },
  { id: 12, firstName: "Suresh",   lastName: "Babu",      email: "suresh.babu@nexacore.com",     phone: "9876543221", department: "Finance",      designation: "Tax Consultant",       salary: 870000,  joinDate: "2020-09-09", status: "Inactive" },
  { id: 13, firstName: "Meera",    lastName: "Krishnan",  email: "meera.krishnan@nexacore.com",  phone: "9876543222", department: "Engineering",  designation: "QA Engineer",          salary: 700000,  joinDate: "2023-01-05", status: "Active"   },
  { id: 14, firstName: "Deepak",   lastName: "Nair",      email: "deepak.nair@nexacore.com",     phone: "9876543223", department: "Marketing",    designation: "Brand Manager",        salary: 810000,  joinDate: "2018-12-18", status: "Active"   },
  { id: 15, firstName: "Kavya",    lastName: "Menon",     email: "kavya.menon@nexacore.com",     phone: "9876543224", department: "Operations",   designation: "Process Analyst",      salary: 590000,  joinDate: "2021-07-22", status: "Inactive" }
];

const adminCredentials = {
  username: "venkatarao",
  password: "venkat@123"
};
