const authService = (() => {
  let isAuthenticated = false;
  let currentUser = null;

  function signup(username, password) {
    const existing = storageService.getAdminCredentials();
    if (existing.username === username) {
      return { success: false, message: "Username already exists. Please choose a different username." };
    }
    storageService.setAdminCredentials(username, password);
    return { success: true, message: "Account created successfully! Please log in." };
  }

  function login(username, password) {
    const creds = storageService.getAdminCredentials();
    if (creds.username === username && creds.password === password) {
      isAuthenticated = true;
      currentUser = username;
      return { success: true };
    }
    return { success: false, message: "Invalid credentials. Please try again." };
  }

  function logout() {
    isAuthenticated = false;
    currentUser = null;
  }

  function isLoggedIn() {
    return isAuthenticated;
  }

  function getCurrentUser() {
    return currentUser;
  }

  return { signup, login, logout, isLoggedIn, getCurrentUser };
})();