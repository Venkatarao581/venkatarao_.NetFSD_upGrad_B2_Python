const uiService = (() => {
  const DEPT_COLORS = {
    "Engineering": "primary",
    "Marketing":   "warning",
    "HR":          "info",
    "Finance":     "success",
    "Operations":  "danger"
  };

  function deptBadge(dept) {
    const color = DEPT_COLORS[dept] || "secondary";
    return `<span class="badge bg-${color}">${dept}</span>`;
  }

  function statusBadge(status) {
    const color = status === "Active" ? "success" : "danger";
    return `<span class="badge bg-${color}">${status}</span>`;
  }

  function initials(e) {
    return `${e.firstName[0]}${e.lastName[0]}`.toUpperCase();
  }

  function formatSalary(s) {
    return "₹" + Number(s).toLocaleString("en-IN");
  }

  function formatDate(d) {
    if (!d) return "";
    const dt = new Date(d);
    return dt.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  }

  function renderDashboardCards(summary) {
    $("#kpi-total").text(summary.total);
    $("#kpi-active").text(summary.active);
    $("#kpi-inactive").text(summary.inactive);
    $("#kpi-departments").text(summary.departments);
  }

  function renderDepartmentBreakdown(data) {
    let html = "";
    data.forEach(d => {
      html += `
        <tr>
          <td>${deptBadge(d.department)}</td>
          <td>${d.count}</td>
          <td>
            <div class="progress" style="height:8px;">
              <div class="progress-bar bg-primary" style="width:${d.percentage}%"></div>
            </div>
          </td>
          <td>${d.percentage}%</td>
        </tr>`;
    });
    $("#dept-breakdown-body").html(html);
  }

  function renderRecentEmployees(employees) {
    let html = "";
    employees.forEach(e => {
      html += `
        <div class="d-flex align-items-center mb-2 p-2 rounded hover-row">
          <div class="avatar-circle me-3">${initials(e)}</div>
          <div class="flex-grow-1">
            <div class="fw-semibold">${e.firstName} ${e.lastName}</div>
            <div class="text-muted small">${e.designation}</div>
          </div>
          <div class="d-flex gap-1">
            ${deptBadge(e.department)}
            ${statusBadge(e.status)}
          </div>
        </div>`;
    });
    $("#recent-employees-list").html(html || "<p class='text-muted small'>No employees found.</p>");
  }

  
  function renderEmployeeTable(employees) {
    if (employees.length === 0) {
      $("#employee-tbody").html(`
        <tr id="no-results-row">
          <td colspan="9" class="text-center text-muted py-4">
            <i class="bi bi-search fs-3 d-block mb-2"></i>No employees found.
          </td>
        </tr>`);
      $("#employee-count").text("Showing 0 employees");
      return;
    }
    let html = "";
    employees.forEach((e, idx) => {
      html += `
        <tr class="${idx % 2 === 0 ? "table-row-even" : ""}">
          <td>${e.id}</td>
          <td><div class="avatar-circle avatar-sm">${initials(e)}</div></td>
          <td class="fw-semibold">${e.firstName} ${e.lastName}</td>
          <td>${e.email}</td>
          <td>${deptBadge(e.department)}</td>
          <td>${e.designation}</td>
          <td>${formatSalary(e.salary)}</td>
          <td>${formatDate(e.joinDate)}</td>
          <td>${statusBadge(e.status)}</td>
          <td>
            <button class="btn btn-sm btn-outline-info me-1 btn-view" data-id="${e.id}" title="View"><i class="bi bi-eye"></i></button>
            <button class="btn btn-sm btn-outline-warning me-1 btn-edit" data-id="${e.id}" title="Edit"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-outline-danger btn-delete" data-id="${e.id}" title="Delete"><i class="bi bi-trash"></i></button>
          </td>
        </tr>`;
    });
    $("#employee-tbody").html(html);
    const count = employees.length;
    $("#employee-count").text(`Showing ${count} employee${count !== 1 ? "s" : ""}`);
  }

  function populateForm(employee) {
    $("#emp-firstName").val(employee.firstName);
    $("#emp-lastName").val(employee.lastName);
    $("#emp-email").val(employee.email);
    $("#emp-phone").val(employee.phone);
    $("#emp-department").val(employee.department);
    $("#emp-designation").val(employee.designation);
    $("#emp-salary").val(employee.salary);
    $("#emp-joinDate").val(employee.joinDate);
    $("#emp-status").val(employee.status);
    $("#editing-id").val(employee.id);
    $("#employeeModalLabel").text("Edit Employee");
    $("#btn-save-employee").text("Update Employee");
  }

  function showModal(type, employee) {
    if (type === "view") {
      $("#view-avatar").text(initials(employee));
      $("#view-name").text(`${employee.firstName} ${employee.lastName}`);
      $("#view-dept-badge").html(deptBadge(employee.department));
      $("#view-email").text(employee.email);
      $("#view-phone").text(employee.phone);
      $("#view-designation").text(employee.designation);
      $("#view-salary").text(formatSalary(employee.salary));
      $("#view-joinDate").text(formatDate(employee.joinDate));
      $("#view-status").html(statusBadge(employee.status));
      const viewModal = new bootstrap.Modal(document.getElementById("viewModal"));
      viewModal.show();
    }
  }

  function showToast(message, type = "success") {
    const colorMap = { success: "bg-success", danger: "bg-danger", warning: "bg-warning", info: "bg-info" };
    const bg = colorMap[type] || "bg-success";
    $("#toast-message").text(message);
    $("#app-toast").removeClass("bg-success bg-danger bg-warning bg-info").addClass(bg);
    const toast = new bootstrap.Toast(document.getElementById("app-toast"), { delay: 3000 });
    toast.show();
  }

  function showInlineErrors(errors) {
    $(".is-invalid").removeClass("is-invalid");
    $(".invalid-feedback").text("");
    Object.keys(errors).forEach(field => {
      $(`#emp-${field}, #auth-${field}`).addClass("is-invalid");
      $(`#err-${field}`).text(errors[field]);
    });
  }

  function clearForm() {
    $("#employee-form")[0].reset();
    $(".is-invalid").removeClass("is-invalid");
    $(".invalid-feedback").text("");
    $("#editing-id").val("");
    $("#employeeModalLabel").text("Add Employee");
    $("#btn-save-employee").text("Save Employee");
  }

  function populateDeptFilter() {
    const depts = employeeService.getDepartments();
    let opts = `<option value="All">All Departments</option>`;
    depts.forEach(d => { opts += `<option value="${d}">${d}</option>`; });
    $("#filter-dept").html(opts);
  }

  function showApp(username) {
    $("#view-signup, #view-login").hide();
    $("#view-app").show();
    $("#navbar-username").text(username);
  }

  function showLogin() {
    $("#view-signup, #view-app").hide();
    $("#view-login").show();
    $("#login-form")[0].reset();
    $(".is-invalid").removeClass("is-invalid");
    $(".invalid-feedback").text("");
  }

  function showSignup() {
    $("#view-login, #view-app").hide();
    $("#view-signup").show();
  }

  function showSection(section) {
    if (section === "dashboard") {
      $("#section-dashboard").show();
      $("#section-employees").hide();
      $("#nav-dashboard").addClass("active");
      $("#nav-employees").removeClass("active");
    } else {
      $("#section-dashboard").hide();
      $("#section-employees").show();
      $("#nav-dashboard").removeClass("active");
      $("#nav-employees").addClass("active");
    }
  }

  return {
    renderDashboardCards, renderDepartmentBreakdown, renderRecentEmployees,
    renderEmployeeTable, populateForm, showModal, showToast, showInlineErrors,
    clearForm, populateDeptFilter, showApp, showLogin, showSignup, showSection
  };
})();