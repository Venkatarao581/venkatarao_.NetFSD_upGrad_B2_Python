const storageService = (() => {

  function getAll() {
    return [...employees];
  }

  function getById(id) {
    return employees.find(e => e.id === id);
  }

  function add(employee) {
    employees.push(employee);
  }


  function update(id, data) {
    const index = employees.findIndex(e => e.id === id);
    if (index !== -1) {
      employees[index] = { ...employees[index], ...data };
    }
  }

  function remove(id) {
    const index = employees.findIndex(e => e.id === id);
    if (index !== -1) {
      employees.splice(index, 1);
    }
  }

  function nextId() {
    if (employees.length === 0) return 1;
    return Math.max(...employees.map(e => e.id)) + 1;
  }

  function getAdminCredentials() {
    return adminCredentials;
  }


  function setAdminCredentials(username, password) {
    adminCredentials.username = username;
    adminCredentials.password = password;
  }

  return { getAll, getById, add, update, remove, nextId, getAdminCredentials, setAdminCredentials };
})();