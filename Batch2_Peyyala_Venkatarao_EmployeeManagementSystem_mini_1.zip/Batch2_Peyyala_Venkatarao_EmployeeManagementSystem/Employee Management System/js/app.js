$(document).ready(function () {
  let currentSearch = "";
  let currentDept   = "All";
  let currentStatus = "All";
  let sortField     = null;
  let sortDir       = "asc";

  function init() {
    if (authService.isLoggedIn()) {
      loadApp();
    } else {
      uiService.showLogin();
    }
  }

  function loadApp() {
    uiService.showApp(authService.getCurrentUser());
    uiService.populateDeptFilter();
    refreshDashboard();
    refreshEmployeeTable();
    uiService.showSection("dashboard");
  }

  function refreshDashboard() {
    const summary    = dashboardService.getSummary();
    const breakdown  = dashboardService.getDepartmentBreakdown();
    const recent     = dashboardService.getRecentEmployees(5);
    uiService.renderDashboardCards(summary);
    uiService.renderDepartmentBreakdown(breakdown);
    uiService.renderRecentEmployees(recent);
  }

  function refreshEmployeeTable() {
    let results = employeeService.applyFilters(currentSearch, currentDept, currentStatus);
    if (sortField) results = employeeService.sortBy(results, sortField, sortDir);
    uiService.renderEmployeeTable(results);
  }

  $("#signup-form").on("submit", function (e) {
    e.preventDefault();
    const formData = {
      username:        $("#auth-username").val().trim(),
      password:        $("#auth-password").val(),
      confirmPassword: $("#auth-confirmPassword").val()
    };
    const errors = validationService.validateAuthForm(formData);
    if (Object.keys(errors).length > 0) {
      uiService.showInlineErrors(errors);
      return;
    }
    const result = authService.signup(formData.username, formData.password);
    if (!result.success) {
      uiService.showInlineErrors({ username: result.message });
      return;
    }
    uiService.showToast(result.message, "success");
    setTimeout(() => uiService.showLogin(), 1500);
  });

  $("#link-to-login").on("click", function (e) {
    e.preventDefault();
    uiService.showLogin();
  });

  $("#login-form").on("submit", function (e) {
    e.preventDefault();
    const username = $("#login-username").val().trim();
    const password = $("#login-password").val();
    if (!username || !password) {
      if (!username) $("#login-username").addClass("is-invalid");
      if (!password) $("#login-password").addClass("is-invalid");
      return;
    }
    const result = authService.login(username, password);
    if (!result.success) {
      $("#login-error").text(result.message).show();
      return;
    }
    $("#login-error").hide();
    uiService.showToast("Welcome back, " + authService.getCurrentUser() + "!", "success");
    loadApp();
  });

  $("#link-to-signup").on("click", function (e) {
    e.preventDefault();
    uiService.showSignup();
  });

  $("#btn-logout").on("click", function () {
    authService.logout();
    uiService.showToast("Logged out successfully.", "info");
    setTimeout(() => uiService.showLogin(), 800);
  });

  $("#nav-dashboard").on("click", function (e) {
    e.preventDefault();
    uiService.showSection("dashboard");
  });

  $("#nav-employees").on("click", function (e) {
    e.preventDefault();
    uiService.showSection("employees");
  });

  $("#btn-nav-add-employee, #btn-add-employee").on("click", function () {
    uiService.clearForm();
    uiService.showSection("employees");
    const modal = new bootstrap.Modal(document.getElementById("employeeModal"));
    modal.show();
  });

  $("#search-input").on("input", function () {
    currentSearch = $(this).val();
    refreshEmployeeTable();
  });

  $("#filter-dept").on("change", function () {
    currentDept = $(this).val();
    refreshEmployeeTable();
  });

  $(".btn-status-filter").on("click", function () {
    $(".btn-status-filter").removeClass("active");
    $(this).addClass("active");
    currentStatus = $(this).data("status");
    refreshEmployeeTable();
  });

  $(document).on("click", ".sortable", function () {
    const field = $(this).data("sort");
    if (sortField === field) {
      sortDir = sortDir === "asc" ? "desc" : "asc";
    } else {
      sortField = field;
      sortDir = "asc";
    }
    $(".sort-icon").text("⇅");
    $(this).find(".sort-icon").text(sortDir === "asc" ? "▲" : "▼");
    refreshEmployeeTable();
  });
  $("#btn-save-employee").on("click", function () {
    const formData = {
      firstName:   $("#emp-firstName").val(),
      lastName:    $("#emp-lastName").val(),
      email:       $("#emp-email").val(),
      phone:       $("#emp-phone").val(),
      department:  $("#emp-department").val(),
      designation: $("#emp-designation").val(),
      salary:      $("#emp-salary").val(),
      joinDate:    $("#emp-joinDate").val(),
      status:      $("#emp-status").val(),
      editingId:   $("#editing-id").val()
    };
    const errors = validationService.validateEmployeeForm(formData);
    if (Object.keys(errors).length > 0) {
      uiService.showInlineErrors(errors);
      return;
    }
    const editId = $("#editing-id").val();
    if (editId) {
      employeeService.update(Number(editId), formData);
      uiService.showToast("Employee updated successfully.", "success");
    } else {
      employeeService.add(formData);
      uiService.showToast("Employee added successfully.", "success");
    }
    bootstrap.Modal.getInstance(document.getElementById("employeeModal")).hide();
    uiService.clearForm();
    uiService.populateDeptFilter();
    refreshDashboard();
    refreshEmployeeTable();
  });

  $(document).on("click", ".btn-view", function () {
    const id = Number($(this).data("id"));
    const employee = employeeService.getById(id);
    if (employee) uiService.showModal("view", employee);
  });

  $(document).on("click", ".btn-edit", function () {
    const id = Number($(this).data("id"));
    const employee = employeeService.getById(id);
    if (employee) {
      uiService.populateForm(employee);
      const modal = new bootstrap.Modal(document.getElementById("employeeModal"));
      modal.show();
    }
  });
  let deleteTargetId = null;

  $(document).on("click", ".btn-delete", function () {
    deleteTargetId = Number($(this).data("id"));
    const emp = employeeService.getById(deleteTargetId);
    if (emp) {
      $("#delete-employee-name").text(`${emp.firstName} ${emp.lastName}`);
      const modal = new bootstrap.Modal(document.getElementById("deleteModal"));
      modal.show();
    }
  });

  $("#btn-confirm-delete").on("click", function () {
    if (deleteTargetId) {
      employeeService.remove(deleteTargetId);
      deleteTargetId = null;
      bootstrap.Modal.getInstance(document.getElementById("deleteModal")).hide();
      uiService.showToast("Employee deleted successfully.", "danger");
      uiService.populateDeptFilter();
      refreshDashboard();
      refreshEmployeeTable();
    }
  });

  document.getElementById("employeeModal").addEventListener("hidden.bs.modal", function () {
    uiService.clearForm();
  });

  init();
});