const employeeService = (() => {

  function getAll() {
    return storageService.getAll();
  }

 
  function getById(id) {
    return storageService.getById(id);
  }

  
  function add(data) {
    const employee = {
      id: storageService.nextId(),
      firstName:   data.firstName.trim(),
      lastName:    data.lastName.trim(),
      email:       data.email.trim(),
      phone:       data.phone.trim(),
      department:  data.department,
      designation: data.designation.trim(),
      salary:      Number(data.salary),
      joinDate:    data.joinDate,
      status:      data.status
    };
    storageService.add(employee);
    return employee;
  }

  function update(id, data) {
    storageService.update(id, {
      firstName:   data.firstName.trim(),
      lastName:    data.lastName.trim(),
      email:       data.email.trim(),
      phone:       data.phone.trim(),
      department:  data.department,
      designation: data.designation.trim(),
      salary:      Number(data.salary),
      joinDate:    data.joinDate,
      status:      data.status
    });
  }

  function remove(id) {
    storageService.remove(id);
  }

  function search(query) {
    const q = query.toLowerCase().trim();
    if (!q) return getAll();
    return getAll().filter(e => {
      const fullName = `${e.firstName} ${e.lastName}`.toLowerCase();
      return fullName.includes(q) || e.email.toLowerCase().includes(q);
    });
  }

  function filterByDepartment(dept) {
    if (!dept || dept === "All") return getAll();
    return getAll().filter(e => e.department === dept);
  }


  function filterByStatus(status) {
    if (!status || status === "All") return getAll();
    return getAll().filter(e => e.status === status);
  }

  function applyFilters(searchQuery, dept, status) {
    let results = getAll();
    const q = (searchQuery || "").toLowerCase().trim();
    if (q) {
      results = results.filter(e => {
        const fullName = `${e.firstName} ${e.lastName}`.toLowerCase();
        return fullName.includes(q) || e.email.toLowerCase().includes(q);
      });
    }
    if (dept && dept !== "All") {
      results = results.filter(e => e.department === dept);
    }
    if (status && status !== "All") {
      results = results.filter(e => e.status === status);
    }
    return results;
  }

  function sortBy(list, field, direction) {
    const sorted = [...list];
    sorted.sort((a, b) => {
      let valA, valB;
      if (field === "name") {
        valA = a.lastName.toLowerCase();
        valB = b.lastName.toLowerCase();
        return direction === "asc" ? valA.localeCompare(valB) : valB.localeCompare(valA);
      }
      if (field === "salary") {
        valA = a.salary;
        valB = b.salary;
      }
      if (field === "joinDate") {
        valA = new Date(a.joinDate);
        valB = new Date(b.joinDate);
      }
      if (valA < valB) return direction === "asc" ? -1 : 1;
      if (valA > valB) return direction === "asc" ?  1 : -1;
      return 0;
    });
    return sorted;
  }

  function getDepartments() {
    return [...new Set(getAll().map(e => e.department))].sort();
  }

  return { getAll, getById, add, update, remove, search, filterByDepartment, filterByStatus, applyFilters, sortBy, getDepartments };
})();