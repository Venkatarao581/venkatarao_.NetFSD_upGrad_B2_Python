from datetime import datetime
from utils.classifier import detect_type, detect_severity

SEVERITY_ORDER = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}

class Incident:
    def __init__(self, id, title, description, reported_by, timestamp, assigned_team):
        self.id = id
        self.title = title
        self.description = description
        self.reported_by = reported_by
        self.timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        self.assigned_team = assigned_team
        self._severity = None
        self.ticket_ids = {}
        self.incident_type = 'general'

    def classify(self):
        raise NotImplementedError('Subclasses must implement classify()')

    @property
    def severity(self):
        return self._severity

    def __lt__(self, other):
        return SEVERITY_ORDER.get(self._severity, 99) < SEVERITY_ORDER.get(other._severity, 99)

    def __str__(self):
        return f"[{self.id}] {self.title} | Type: {self.incident_type} | Severity: {self._severity}"

    def __repr__(self):
        return f"Incident(id={self.id!r}, type={self.incident_type!r}, severity={self._severity!r})"

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'reported_by': self.reported_by,
            'timestamp': self.timestamp.isoformat(),
            'assigned_team': self.assigned_team,
            'incident_type': self.incident_type,
            'severity': self._severity,
            'ticket_ids': self.ticket_ids,
        }

    @staticmethod
    def validate_json(record):
        required = {'id', 'title', 'description', 'reported_by', 'timestamp', 'assigned_team'}
        missing = required - record.keys()
        if missing:
            raise ValueError(f"Missing fields: {missing}")
        return True


class NetworkIncident(Incident):
    def __init__(self, id, title, description, reported_by, timestamp,
                 assigned_team, affected_host='unknown', protocol='unknown'):
        super().__init__(id, title, description, reported_by, timestamp, assigned_team)
        self.affected_host = affected_host
        self.protocol = protocol
        self.incident_type = 'network'

    def classify(self):
        self._severity = detect_severity(self.title + ' ' + self.description)
        return self._severity

    def escalate(self):
        print(f"  [ESCALATE] Paging on-call network team for {self.id}: {self.title}")

    def to_dict(self):
        d = super().to_dict()
        d.update({'affected_host': self.affected_host, 'protocol': self.protocol})
        return d


class AppIncident(Incident):
    def __init__(self, id, title, description, reported_by, timestamp,
                 assigned_team, app_name='unknown', error_code='N/A'):
        super().__init__(id, title, description, reported_by, timestamp, assigned_team)
        self.app_name = app_name
        self.error_code = error_code
        self.incident_type = 'app'

    def classify(self):
        self._severity = detect_severity(self.title + ' ' + self.description)
        return self._severity

    def get_stack_trace(self):
        return (f"  [STACK TRACE] {self.id} - {self.app_name}\n"
                f"  java.lang.{self.error_code}\n"
                f"        at com.company.service.Handler.process(Handler.java:101)")

    def to_dict(self):
        d = super().to_dict()
        d.update({'app_name': self.app_name, 'error_code': self.error_code})
        return d


class SecurityIncident(Incident):
    def __init__(self, id, title, description, reported_by, timestamp,
                 assigned_team, threat_type='unknown', source_ip='unknown'):
        super().__init__(id, title, description, reported_by, timestamp, assigned_team)
        self.threat_type = threat_type
        self.source_ip = source_ip
        self.incident_type = 'security'

    def classify(self):
        self._severity = detect_severity(self.title + ' ' + self.description)
        return self._severity

    def notify_soc(self):
        print(f"  [SOC ALERT] {self.id} - Threat: {self.threat_type} | IP: {self.source_ip}")

    def to_dict(self):
        d = super().to_dict()
        d.update({'threat_type': self.threat_type, 'source_ip': self.source_ip})
        return d


class IncidentIterator:
    def __init__(self, incidents, severity_filter=None):
        if severity_filter:
            self._incidents = [i for i in incidents if i.severity == severity_filter]
        else:
            self._incidents = list(incidents)
        self._index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self._index >= len(self._incidents):
            raise StopIteration
        incident = self._incidents[self._index]
        self._index += 1
        return incident


def batch_incidents(incidents, batch_size=3):
    for i in range(0, len(incidents), batch_size):
        yield incidents[i: i + batch_size]


def create_incident(record):
    Incident.validate_json(record)
    combined = record['title'] + ' ' + record['description']
    inc_type = detect_type(combined)
    common = {
        'id': record['id'],
        'title': record['title'],
        'description': record['description'],
        'reported_by': record['reported_by'],
        'timestamp': record['timestamp'],
        'assigned_team': record['assigned_team'],
    }
    if inc_type == 'network':
        return NetworkIncident(**common)
    elif inc_type == 'security':
        return SecurityIncident(**common)
    elif inc_type == 'app':
        return AppIncident(**common)
    else:
        inc = Incident(**common)
        inc.incident_type = 'general'
        inc._severity = detect_severity(combined)
        inc.classify = lambda: inc._severity
        return inc