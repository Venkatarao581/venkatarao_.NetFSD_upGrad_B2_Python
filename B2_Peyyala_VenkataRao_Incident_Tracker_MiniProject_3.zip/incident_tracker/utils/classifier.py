﻿import re

NETWORK_PATTERN = re.compile(r"TCP|UDP|ICMP|VLAN|switch|firewall|DNS|subnet|packet", re.IGNORECASE)
SECURITY_PATTERN = re.compile(r"breach|ransomware|malware|phishing|unauthorized|threat|suspicious|brute", re.IGNORECASE)
APP_PATTERN = re.compile(r"NullPointerException|Exception|HTTP|error.code|API|latency|scheduled.job", re.IGNORECASE)
CRITICAL_PATTERN = re.compile(r"outage|down|breach|ransomware|production|critical", re.IGNORECASE)
HIGH_PATTERN = re.compile(r"timeout|failing|unavailable|unreachable|brute", re.IGNORECASE)
MEDIUM_PATTERN = re.compile(r"slow|degraded|warning|intermittent|packet", re.IGNORECASE)

def detect_type(text):
    if SECURITY_PATTERN.search(text): return "security"
    if NETWORK_PATTERN.search(text): return "network"
    if APP_PATTERN.search(text): return "app"
    return "general"

def detect_severity(text):
    if CRITICAL_PATTERN.search(text): return "critical"
    if HIGH_PATTERN.search(text): return "high"
    if MEDIUM_PATTERN.search(text): return "medium"
    return "low"
