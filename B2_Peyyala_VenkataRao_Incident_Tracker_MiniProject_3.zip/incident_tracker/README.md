﻿# IT Incident Auto-Triage & Tracker - Mini Project 3

## How to Run
1. Open terminal in the incident_tracker folder
2. Run: python main.py
3. Open output/report.html in browser

## Filter by severity
python main.py --severity critical
python main.py --severity high

## Project Structure
- main.py         : Entry point
- config.py       : Settings (MOCK_API=True)
- models/         : Incident classes and Report generator
- services/       : ServiceNow, Jira, Azure Boards integrations
- utils/          : Classifier, Decorators, Helpers
- data/           : incidents.json (12 records)
- output/         : report.html and summary.json generated here
