﻿import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from utils.decorators import log_call, retry

_counter = 0

@log_call
@retry(times=3, delay=1)
def create_snow_ticket(incident):
    global _counter
    _counter += 1
    fake_id = f"MOCK-SNOW-{_counter:03d}"
    print(f"    [SNOW] -> {fake_id}")
    incident.ticket_ids["snow"] = fake_id
    return fake_id
