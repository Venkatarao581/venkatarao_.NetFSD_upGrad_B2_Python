﻿import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from utils.decorators import log_call, retry

_counter = 0

@log_call
@retry(times=3, delay=1)
def create_azure_work_item(incident):
    global _counter
    _counter += 1
    fake_id = f"AZURE-{_counter:03d}"
    print(f"    [AZURE] -> {fake_id}")
    incident.ticket_ids["azure"] = fake_id
    return fake_id
