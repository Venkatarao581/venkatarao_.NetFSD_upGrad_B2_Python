﻿import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from utils.decorators import log_call, retry

_counter = 0

@log_call
@retry(times=3, delay=1)
def create_jira_issue(incident):
    global _counter
    _counter += 1
    fake_key = f"ITOPS-{_counter:03d}"
    print(f"    [JIRA] -> {fake_key}")
    incident.ticket_ids["jira"] = fake_key
    return fake_key
