#!/usr/bin/env python3
import sys, os, json, argparse

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from models.incident import create_incident, batch_incidents, IncidentIterator
from models.report import ReportGenerator
from services.servicenow import create_snow_ticket
from services.jira import create_jira_issue
from services.azure_boards import create_azure_work_item
from utils.helpers import count_by_team, count_by_type, count_by_severity, get_sorted_incidents
import config

def load_incidents(filepath):
    print("\n" + "="*60)
    print("  STEP 1: Loading incidents")
    print("="*60)
    with open(filepath, 'r', encoding='utf-8') as f:
        raw_records = json.load(f)
    incidents = []
    for record in raw_records:
        try:
            inc = create_incident(record)
            incidents.append(inc)
            print(f"  Loaded {inc.id}: [{inc.incident_type.upper()}] {inc.title[:50]}")
        except ValueError as e:
            print(f"  [SKIP] {e}")
    print(f"\n  Total loaded: {len(incidents)} incidents")
    return incidents

def classify_all(incidents):
    print("\n" + "="*60)
    print("  STEP 2: Classifying incidents")
    print("="*60)
    for inc in incidents:
        inc.classify()
        print(f"  {inc.id}: severity={inc.severity:8s} type={inc.incident_type}")
    return incidents

def push_to_platforms(incidents):
    print("\n" + "="*60)
    print("  STEP 4: Pushing tickets to platforms")
    print("="*60)
    for batch_num, batch in enumerate(batch_incidents(incidents, batch_size=3), start=1):
        print(f"\n  --- Batch {batch_num} ---")
        for inc in batch:
            print(f"\n  Processing {inc.id}: {inc.title[:45]}")
            create_snow_ticket(inc)
            create_jira_issue(inc)
            create_azure_work_item(inc)
            if inc.incident_type == 'network':
                inc.escalate()
            elif inc.incident_type == 'security':
                inc.notify_soc()
            elif inc.incident_type == 'app':
                print(inc.get_stack_trace())

def print_summary(incidents):
    print("\n" + "="*60)
    print("  STEP 5: Summary")
    print("="*60)
    for sev, count in sorted(count_by_severity(incidents).items()):
        print(f"  {sev:10s}: {count}")
    critical_list = list(IncidentIterator(incidents, severity_filter='critical'))
    if critical_list:
        print(f"\n  Critical incidents ({len(critical_list)}):")
        for inc in critical_list:
            print(f"    WARNING  {inc.id}: {inc.title}")

def generate_reports(incidents):
    print("\n" + "="*60)
    print("  STEP 6: Generating reports")
    print("="*60)
    reporter = ReportGenerator(get_sorted_incidents(incidents))
    reporter.generate_html(os.path.join(BASE_DIR, 'output', 'report.html'))
    reporter.export_json(os.path.join(BASE_DIR, 'output', 'summary.json'))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--severity', choices=['critical','high','medium','low'], default=None)
    args = parser.parse_args()

    print("\n" + "="*60)
    print("  IT Incident Auto-Triage & Tracker - Mini Project 3")
    print(f"  Mode: {'MOCK' if config.MOCK_API else 'LIVE'}")
    print("="*60)

    data_file = os.path.join(BASE_DIR, 'data', 'incidents.json')
    incidents = load_incidents(data_file)
    incidents = classify_all(incidents)
    if args.severity:
        incidents = [i for i in incidents if i.severity == args.severity]
        print(f"\n  [FILTER] --severity {args.severity}: {len(incidents)} incidents")
    push_to_platforms(incidents)
    print_summary(incidents)
    generate_reports(incidents)

    print("\n" + "="*60)
    print("  DONE! Open output/report.html in your browser!")
    print("="*60 + "\n")

if __name__ == '__main__':
    main()