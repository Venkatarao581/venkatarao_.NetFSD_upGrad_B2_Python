MOCK_API = True

SNOW_INSTANCE    = "your-instance"
SNOW_USERNAME    = "admin"
SNOW_PASSWORD    = "your-password"

JIRA_DOMAIN      = "your-domain"
JIRA_EMAIL       = "you@example.com"
JIRA_API_TOKEN   = "your-jira-api-token"
JIRA_PROJECT_KEY = "ITOPS"

AZURE_ORG        = "your-org"
AZURE_PROJECT    = "your-project"
AZURE_PAT        = "your-personal-access-token"